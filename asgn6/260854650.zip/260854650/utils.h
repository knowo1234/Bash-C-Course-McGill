


//parse function
void parse(char *s,int *base,int *exponent);
//powi
int powi(int x, int exponent);
